BEGIN;
CREATE SCHEMA IF NOT EXISTS iam;
CREATE SCHEMA IF NOT EXISTS billing;

CREATE TABLE iam.tenants (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  slug citext UNIQUE NOT NULL,
  legal_name text NOT NULL,
  status record_status NOT NULL DEFAULT 'approved',
  data_region text,
  classification_ceiling data_classification NOT NULL DEFAULT 'customer_confidential',
  created_at timestamptz NOT NULL DEFAULT now(),
  updated_at timestamptz NOT NULL DEFAULT now()
);
CREATE TABLE iam.subjects (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  external_subject text UNIQUE,
  email citext,
  display_name text,
  subject_type text NOT NULL CHECK (subject_type IN ('user','service_account')),
  status record_status NOT NULL DEFAULT 'approved',
  created_at timestamptz NOT NULL DEFAULT now(),
  updated_at timestamptz NOT NULL DEFAULT now()
);
CREATE TABLE iam.memberships (
  tenant_id uuid NOT NULL REFERENCES iam.tenants(id) ON DELETE CASCADE,
  subject_id uuid NOT NULL REFERENCES iam.subjects(id) ON DELETE CASCADE,
  role_key text NOT NULL,
  attributes jsonb NOT NULL DEFAULT '{}'::jsonb,
  valid_from timestamptz NOT NULL DEFAULT now(),
  valid_to timestamptz,
  created_at timestamptz NOT NULL DEFAULT now(),
  PRIMARY KEY (tenant_id, subject_id, role_key)
);
CREATE TABLE iam.reviewer_authorities (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  subject_id uuid NOT NULL REFERENCES iam.subjects(id) ON DELETE CASCADE,
  jurisdiction_ids uuid[] NOT NULL DEFAULT '{}',
  topic_keys text[] NOT NULL DEFAULT '{}',
  language_keys text[] NOT NULL DEFAULT '{}',
  maximum_risk risk_tier NOT NULL DEFAULT 'moderate',
  legal_authority boolean NOT NULL DEFAULT false,
  quality_authority boolean NOT NULL DEFAULT false,
  trade_authority boolean NOT NULL DEFAULT false,
  valid_from timestamptz NOT NULL DEFAULT now(),
  valid_to timestamptz
);
CREATE TABLE iam.access_policies (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  tenant_id uuid REFERENCES iam.tenants(id) ON DELETE CASCADE,
  policy_key text NOT NULL,
  version integer NOT NULL,
  policy_document jsonb NOT NULL,
  status record_status NOT NULL DEFAULT 'draft',
  effective_from timestamptz,
  effective_to timestamptz,
  UNIQUE (tenant_id, policy_key, version)
);
CREATE TABLE billing.plans (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  plan_key text UNIQUE NOT NULL,
  name text NOT NULL,
  status record_status NOT NULL DEFAULT 'draft',
  currency char(3),
  billing_interval text,
  price_minor bigint,
  public_description text,
  created_at timestamptz NOT NULL DEFAULT now()
);
CREATE TABLE billing.entitlements (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  tenant_id uuid NOT NULL REFERENCES iam.tenants(id) ON DELETE CASCADE,
  plan_id uuid REFERENCES billing.plans(id),
  entitlement_key text NOT NULL,
  scope jsonb NOT NULL DEFAULT '{}'::jsonb,
  usage_limit numeric,
  valid_from timestamptz NOT NULL DEFAULT now(),
  valid_to timestamptz,
  UNIQUE (tenant_id, entitlement_key, valid_from)
);
CREATE INDEX memberships_subject_idx ON iam.memberships(subject_id, tenant_id);
CREATE INDEX entitlements_tenant_idx ON billing.entitlements(tenant_id, entitlement_key);
COMMIT;
